"""
backend.py — bridge between the Python GUI and the C# core (SuperClicker.exe).

Class ClickerBridge:
  * writes settings into clicker.cfg (key=value), read by C# in headless mode;
  * launches SuperClicker.exe --config clicker.cfg;
  * reads the process stdout (READY/STATUS/RELOAD/EXIT) on a background thread;
  * exposes the current state to the HTML window.

Used from app.py. No third-party dependencies here — standard library only.
"""

import os
import sys
import shutil
import subprocess
import threading
import time

# ── Virtual-key (VK) codes for the most common toggle keys ───────────────────
VK_CODES = {
    "F1": 0x70, "F2": 0x71, "F3": 0x72, "F4": 0x73, "F5": 0x74,
    "F7": 0x76, "F8": 0x77, "F9": 0x78, "F10": 0x79, "F11": 0x7A, "F12": 0x7B,
    "Q": 0x51, "E": 0x45, "R": 0x52, "T": 0x54, "Z": 0x5A, "X": 0x58,
    "C": 0x43, "V": 0x56, "B": 0x42, "TAB": 0x09, "CAPSLOCK": 0x14,
    "INSERT": 0x2D, "HOME": 0x24, "END": 0x23, "PAGEUP": 0x21, "PAGEDOWN": 0x22,
    "NUM0": 0x60, "NUM1": 0x61, "MOUSE4": 0x05, "MOUSE5": 0x06,
}
# F6 is reserved in C# as the emergency stop — we don't offer it.


def _is_frozen():
    """True when running inside a PyInstaller-built .exe."""
    return getattr(sys, "frozen", False)


def resource_path(*parts):
    """
    Path to a bundled, read-only asset (UI html, the C# core exe).
    In a PyInstaller build these live in sys._MEIPASS; from source they live
    next to the project root.
    """
    if _is_frozen():
        base = sys._MEIPASS  # temp dir where PyInstaller unpacks bundled data
    else:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, *parts)


def data_dir():
    """
    A writable folder for runtime files (clicker.cfg).
    - frozen: a 'flaw_data' folder next to the running .exe (portable);
    - source: the project's bin/ folder.
    """
    if _is_frozen():
        d = os.path.join(os.path.dirname(sys.executable), "flaw_data")
    else:
        d = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "bin")
    os.makedirs(d, exist_ok=True)
    return d


# Read-only core executable (bundled in the build, or bin/ from source).
EXE_PATH = resource_path("bin", "SuperClicker.exe")
# Writable config the C# core reads.
CFG_PATH = os.path.join(data_dir(), "clicker.cfg")
BIN_DIR = os.path.dirname(CFG_PATH)


class ClickerBridge:
    def __init__(self):
        self.proc = None
        self.reader_thread = None
        self.lock = threading.Lock()
        self.state = {
            "running": False,     # exe is launched
            "active": False,      # clicker is actually clicking
            "cps": 50,
            "mode": "alt",        # alt | sim
            "toggle_key": "F3",
            "autostart": False,
            "last_message": "Ready to launch",
            "exe_found": os.path.exists(EXE_PATH),
        }

    # ---- API exposed to JavaScript via pywebview ----------------------------
    def get_state(self):
        with self.lock:
            return dict(self.state)

    def vk_list(self):
        return sorted(VK_CODES.keys())

    def start(self, cps, mode, toggle_key, autostart):
        """Start the core with the given settings."""
        cps = max(1, min(int(cps), 1000))
        mode = "sim" if str(mode).lower() == "sim" else "alt"
        toggle_key = toggle_key if toggle_key in VK_CODES else "F3"
        autostart = bool(autostart)

        with self.lock:
            self.state.update(cps=cps, mode=mode, toggle_key=toggle_key,
                              autostart=autostart)

        self._write_cfg(cps, mode, toggle_key, autostart)

        if not os.path.exists(EXE_PATH):
            with self.lock:
                self.state["last_message"] = "Core not found"
                self.state["exe_found"] = False
            return self.get_state()

        # Restart if already running.
        self.stop()

        try:
            self.proc = subprocess.Popen(
                [EXE_PATH, "--config", CFG_PATH],
                cwd=BIN_DIR,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                text=True,
                bufsize=1,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except OSError as e:
            with self.lock:
                self.state["last_message"] = f"Failed to start exe: {e}"
            return self.get_state()

        with self.lock:
            self.state["running"] = True
            self.state["active"] = autostart
            self.state["last_message"] = "Core launched"

        self.reader_thread = threading.Thread(
            target=self._read_loop, daemon=True)
        self.reader_thread.start()
        return self.get_state()

    def update(self, cps, mode, toggle_key, autostart):
        """Hot-edit the cfg — C# will reload it without a restart."""
        cps = max(1, min(int(cps), 1000))
        mode = "sim" if str(mode).lower() == "sim" else "alt"
        toggle_key = toggle_key if toggle_key in VK_CODES else "F3"
        with self.lock:
            self.state.update(cps=cps, mode=mode, toggle_key=toggle_key,
                              autostart=bool(autostart))
        self._write_cfg(cps, mode, toggle_key, autostart)
        with self.lock:
            self.state["last_message"] = "Settings updated"
        return self.get_state()

    def stop(self):
        """Stop the core process."""
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
            except OSError:
                pass
        self.proc = None
        with self.lock:
            self.state["running"] = False
            self.state["active"] = False
            self.state["last_message"] = "Stopped"
        return self.get_state()

    # ---- internals ----------------------------------------------------------
    def _write_cfg(self, cps, mode, toggle_key, autostart):
        os.makedirs(BIN_DIR, exist_ok=True)
        vk = VK_CODES.get(toggle_key, 0x72)
        text = (
            "# auto-generated by SuperClicker GUI\n"
            f"cps={int(cps)}\n"
            f"mode={mode}\n"
            f"toggleKey={vk}\n"
            f"autostart={'1' if autostart else '0'}\n"
        )
        # Atomic write so C# never reads a half-written file.
        tmp = CFG_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, CFG_PATH)

    def _read_loop(self):
        proc = self.proc
        if not proc or not proc.stdout:
            return
        for line in proc.stdout:
            line = line.strip()
            if not line:
                continue
            self._handle_line(line)
        # stdout closed — the process has exited.
        with self.lock:
            self.state["running"] = False
            self.state["active"] = False
            if self.state["last_message"] not in ("Stopped",):
                self.state["last_message"] = "Core has exited"

    def _handle_line(self, line):
        with self.lock:
            if line.startswith("STATUS:ACTIVE"):
                self.state["active"] = True
                self.state["last_message"] = "Clicker RUNNING"
            elif line.startswith("STATUS:PAUSED"):
                self.state["active"] = False
                self.state["last_message"] = "Clicker paused"
            elif line.startswith("READY") or line.startswith("RELOAD"):
                self.state["last_message"] = "Core ready"
            elif line.startswith("EXIT"):
                self.state["active"] = False
                self.state["running"] = False
                self.state["last_message"] = "Emergency stop (F6)"
