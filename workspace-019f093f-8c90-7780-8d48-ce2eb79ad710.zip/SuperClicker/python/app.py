"""
app.py — GUI entry point.

Opens a polished HTML/CSS/JS window (pywebview) and connects it to the C# core
through the ClickerBridge class (backend.py).

Run:
    pip install pywebview
    python app.py

If pywebview is not installed, the script says so and falls back to opening the
UI in a regular browser (demo mode without core control).
"""

import os
import sys
import webbrowser

from backend import ClickerBridge, resource_path

UI_INDEX = resource_path("ui", "index.html")


class Api:
    """Object whose methods are visible from JavaScript as window.pywebview.api.*"""

    def __init__(self):
        self.bridge = ClickerBridge()
        self.window = None  # set after create_window

    # ── window controls (custom title bar) ────────────────────
    def win_minimize(self):
        if self.window:
            self.window.minimize()

    def win_close(self):
        self.bridge.stop()
        if self.window:
            self.window.destroy()

    def get_state(self):
        return self.bridge.get_state()

    def vk_list(self):
        return self.bridge.vk_list()

    def start(self, cps, mode, toggle_key, autostart):
        return self.bridge.start(cps, mode, toggle_key, autostart)

    def update(self, cps, mode, toggle_key, autostart):
        return self.bridge.update(cps, mode, toggle_key, autostart)

    def stop(self):
        return self.bridge.stop()


def main():
    api = Api()

    try:
        import webview
    except ImportError:
        print("=" * 60)
        print("pywebview is not installed. Install the dependency:")
        print("    pip install pywebview")
        print("=" * 60)
        print("Opening the UI in a browser (demo without core control)...")
        webbrowser.open("file://" + UI_INDEX.replace("\\", "/"))
        return

    window = webview.create_window(
        title="SuperClicker",
        url=UI_INDEX,
        js_api=api,
        width=980,
        height=730,
        min_size=(760, 600),
        background_color="#050607",
        resizable=True,
        frameless=True,          # custom frame/title bar in HTML
        easy_drag=False,         # dragging handled via CSS -webkit-app-region
    )
    api.window = window

    # Gracefully shut the core down when the window closes.
    def on_closing():
        api.bridge.stop()

    window.events.closing += on_closing
    webview.start()


if __name__ == "__main__":
    main()
