@echo off
REM ============================================================
REM  flaw - one-click DEV launcher (runs from source)
REM  Builds the C# core on first run, then opens the window.
REM  For distribution, use build_exe\build_exe.bat to make flaw.exe.
REM ============================================================
setlocal
cd /d "%~dp0"

REM Build the C# core once if it's missing.
if not exist "bin\SuperClicker.exe" (
    echo Building the core (first run only)...
    call "csharp\build.bat"
)

REM Install pywebview the first time.
python -c "import webview" 2>nul
if %ERRORLEVEL% neq 0 (
    echo Installing pywebview...
    python -m pip install --upgrade pip
    python -m pip install pywebview
)

cd python
python app.py
if %ERRORLEVEL% neq 0 pause
