# SuperClicker — User Guide

A polished **Python + HTML/CSS/JS** window that controls your high-precision
**C#** clicker (SendInput + scancodes + hybrid timer).

> ⚠️ Platform: **Windows x64**. The core uses WinAPI (`user32.dll`,
> `kernel32.dll`, `winmm.dll`), so it builds and runs on Windows only.

---

## 1. Project structure

```
SuperClicker/
├── csharp/
│   ├── clicker.cs        ← C# core (headless/GUI mode)
│   └── build.bat         ← builds the core -> bin/SuperClicker.exe
├── python/
│   ├── app.py            ← opens the window (pywebview)
│   ├── backend.py        ← bridge Python ↔ exe (cfg + stdout reader)
│   └── requirements.txt  ← dependency: pywebview
├── ui/
│   └── index.html        ← the window (dark / noir / graphite, Space Grotesk)
├── bin/
│   ├── SuperClicker.exe  ← appears after the build
│   └── clicker.cfg       ← settings written by the GUI (auto-created)
├── build_exe/
│   ├── flaw.spec         ← PyInstaller recipe (bundles everything)
│   ├── build_exe.bat     ← makes the standalone flaw.exe
│   └── dist/flaw.exe     ← the file you ship (after building)
├── start.bat             ← one-click DEV launcher (from source)
├── run_gui.bat           ← opens the window (from source)
└── USER_GUIDE.md         ← this file
```

---

## 2. What you need to install

1. **.NET Framework 4.x** — already in Windows (`csc.exe` lives in
   `C:\Windows\Microsoft.NET\Framework64\v4.0.30319\`).
2. **Python 3.9+** — https://python.org (tick "Add to PATH" during install).
3. **pywebview** — installed automatically on the first `run_gui.bat` run,
   or manually:
   ```
   pip install pywebview
   ```

---

## 3. Launch in 3 steps

### Step 1 — build the core
Go into the `csharp` folder and run **`build.bat`**.
Result: `bin/SuperClicker.exe`.

### Step 2 — open the window
Run **`run_gui.bat`** (preferably **as administrator**).
The dark SuperClicker window opens.

### Step 3 — configure and click "Start core"
- **CPS** — speed slider (20–50 for games).
- **Toggle / pause key** — pick one from the list (e.g. `F3`).
- **Mode** — *Alternate* (higher FPS) or *Simultaneous* F+G.
- **Autostart** — click immediately or wait for the key press.

Click **"Start core"**. Then in-game press your chosen key to turn the
clicker on/off.

---

## 4. Controls while running

| Action | How |
|---|---|
| Minimize / close window | the **–** and **✕** buttons top-right (title bar) |
| Drag the window | grab the dark title-bar strip |
| Toggle / pause clicker | the chosen key (e.g. `F3`) |
| **Emergency stop the core** | `F6` (global, any time) |
| Change CPS/mode on the fly | move the controls → click **"Apply settings"** (or they auto-apply after ~0.25 s) |
| Fully stop | the **"Stop"** button in the window |

---

## 5. How it works (short version)

1. The window (`ui/index.html`) collects the settings and calls Python via
   `window.pywebview.api`.
2. `backend.py` writes them into `bin/clicker.cfg` and launches
   `SuperClicker.exe --config bin/clicker.cfg`.
3. C# in headless mode reads the cfg, clicks, and prints status
   (`STATUS:ACTIVE` / `STATUS:PAUSED`) to stdout.
4. Python reads stdout and updates the window state (green/red dot).
5. Change a setting in the window → the cfg is rewritten → C# picks it up
   on the fly (hot reload) without a restart.

**`clicker.cfg` format:**
```
cps=50
mode=alt        # alt = alternate F/G, sim = simultaneous F+G
toggleKey=114   # VK code (114 = F3)
autostart=0
```

---

## 6. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| "SuperClicker.exe not found" | Build the core first: `csharp/build.bat`. |
| Clicks don't reach the game | Run **the game and `run_gui.bat` as administrator**. Anti-cheats with kernel (ring-0) protection may block SendInput. |
| `csc.exe` not found | Check the path in `build.bat`; usually `C:\Windows\Microsoft.NET\Framework64\v4.0.30319\`. |
| Window won't open, webview error | `pip install pywebview`. Without it `app.py` opens the UI in a browser (demo, no control). |
| FPS drops in game | Lower the CPS, choose **Alternate** mode. |

---

## 7. Shipping it on your website (standalone EXE)

To give people a file they can **download and run with no install** (no Python,
no pip), bundle everything into one `flaw.exe`:

1. On **your** PC (the builder), have Python 3.9+ installed.
2. Run **`build_exe\build_exe.bat`**. It will:
   - build the C# core if it's missing,
   - install PyInstaller + pywebview,
   - package **`build_exe\dist\flaw.exe`**.
3. Upload **that single `flaw.exe`** to your site.

Users just double-click `flaw.exe`. At runtime it creates a small `flaw_data`
folder next to itself for its config — nothing else is needed.

The build automatically uses **`build_exe\flaw.ico`** as the app icon and
**`build_exe\version_info.txt`** for the file's Properties → Details
(name "flaw", version 1.0.0.0). Replace the `.ico` to rebrand.

> Tell users to **run flaw.exe as administrator** so clicks reach games.
> Note: a fresh unsigned .exe may trigger SmartScreen ("More info → Run anyway")
> or an antivirus warning — this is normal for autoclickers; code-signing it
> removes the warning but is optional.

---

## 8. Legacy console mode
`SuperClicker.exe` with no arguments works as before — configuration via the
console. The GUI launches it with `--config`, so both modes coexist.

---

## 9. Disclaimer
A tool for personal use and automation. Using auto-clickers may violate the
rules of some online games and services — check their terms. The user is
responsible for how it is used.
