@echo off
REM ============================================================
REM  Build the SuperClicker C# core (x64)
REM  Output: ..\bin\SuperClicker.exe
REM ============================================================

set "csc=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"

if not exist "..\bin" mkdir "..\bin"

"%csc%" /out:..\bin\SuperClicker.exe /optimize /platform:x64 /target:exe clicker.cs

if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERROR] Build failed. Check the path to csc.exe above.
    pause
    exit /b 1
)

echo.
echo Build complete! -> ..\bin\SuperClicker.exe
pause
