using System;
using System.IO;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Threading;

// ============================================================================
//  SuperClicker (X64) — enhanced edition
//  ---------------------------------------------------------------------------
//  The clicker core is unchanged (SendInput + scancodes + hybrid timer +
//  CPU-core affinity); a HEADLESS mode is added so the clicker can be
//  driven from the polished Python+HTML window.
//
//  Launch modes:
//    1) SuperClicker.exe                  -> interactive mode (legacy behaviour,
//                                            configured via the console).
//    2) SuperClicker.exe --config <path>  -> headless: reads settings from a cfg file,
//                                            prints machine-readable status to stdout,
//                                            driven by the Python GUI.
//
//  cfg file format (key=value, one parameter per line):
//    cps=50
//    mode=alt          (alt = alternate F/G, sim = simultaneous F+G)
//    toggleKey=114     (VK code of the on/pause key; 114 = F3)
//    autostart=1       (1 = active immediately, 0 = wait for toggleKey)
//
//  stdout protocol (parsed by Python):
//    READY|cps=..|mode=..|toggleKey=..
//    STATUS:ACTIVE
//    STATUS:PAUSED
//    EXIT
// ============================================================================

class Program
{
    [DllImport("user32.dll")]
    static extern short GetAsyncKeyState(int vKey);

    [DllImport("user32.dll")]
    static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("kernel32.dll")]
    static extern bool QueryPerformanceCounter(out long lpPerformanceCount);

    [DllImport("kernel32.dll")]
    static extern bool QueryPerformanceFrequency(out long lpFrequency);

    // Controls system timer resolution (for precise Sleep in hybrid mode)
    [DllImport("winmm.dll")]
    static extern uint timeBeginPeriod(uint uMilliseconds);

    [DllImport("winmm.dll")]
    static extern uint timeEndPeriod(uint uMilliseconds);

    // Pins the thread to a specific CPU core
    [DllImport("kernel32.dll")]
    static extern IntPtr GetCurrentThread();

    [DllImport("kernel32.dll")]
    static extern UIntPtr SetThreadAffinityMask(IntPtr hThread, UIntPtr dwThreadAffinityMask);

    // Explicit struct layout for 64-bit systems
    [StructLayout(LayoutKind.Explicit, Size = 40)]
    struct INPUT
    {
        [FieldOffset(0)] public uint type;
        [FieldOffset(8)] public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    const uint INPUT_KEYBOARD = 1;
    const uint KEYEVENTF_KEYUP = 0x0002;
    const uint KEYEVENTF_SCANCODE = 0x0008; // Hardware-press flag (required for GAMES)
    const int  VK_F6 = 0x75;

    // Hardware scancodes (DirectInput) instead of virtual ones
    const ushort DIK_F = 0x21; // Scancode of the F key
    const ushort DIK_G = 0x22; // Scancode of the G key

    static volatile bool g_running     = true;
    static volatile bool g_active      = false;
    static volatile bool g_configuring = true;
    static volatile int  g_cps         = 50;
    static volatile int  g_toggleKey   = 0;
    // Key mode: false = alternate F/G (fewer events, higher FPS),
    //              true  = simultaneous F+G (twice the events)
    static volatile bool g_simultaneous = false;

    // headless mode: settings come from the cfg file, no console dialog.
    static bool g_headless = false;

    // Combined F+G press (legacy mode)
    static INPUT[] g_inputsDown = new INPUT[2];
    static INPUT[] g_inputsUp   = new INPUT[2];

    // Single presses for alternate mode
    static INPUT[] g_fDown = new INPUT[1];
    static INPUT[] g_fUp   = new INPUT[1];
    static INPUT[] g_gDown = new INPUT[1];
    static INPUT[] g_gUp   = new INPUT[1];

    static int     g_inputSize = 0;

    static void Main(string[] args)
    {
        Console.Title = "SuperClicker X64 [F + G]";

        string cfgPath = null;
        for (int i = 0; i < args.Length; i++)
        {
            if ((args[i] == "--config" || args[i] == "-c") && i + 1 < args.Length)
                cfgPath = args[i + 1];
        }
        g_headless = (cfgPath != null);

        g_inputSize = Marshal.SizeOf(typeof(INPUT));

        // KEY F (Down)
        g_inputsDown[0].type = INPUT_KEYBOARD;
        g_inputsDown[0].ki.wScan = DIK_F; // Use the scancode
        g_inputsDown[0].ki.dwFlags = KEYEVENTF_SCANCODE;

        // KEY F (Up)
        g_inputsUp[0].type = INPUT_KEYBOARD;
        g_inputsUp[0].ki.wScan = DIK_F;
        g_inputsUp[0].ki.dwFlags = KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP;

        // KEY G (Down)
        g_inputsDown[1].type = INPUT_KEYBOARD;
        g_inputsDown[1].ki.wScan = DIK_G;
        g_inputsDown[1].ki.dwFlags = KEYEVENTF_SCANCODE;

        // KEY G (Up)
        g_inputsUp[1].type = INPUT_KEYBOARD;
        g_inputsUp[1].ki.wScan = DIK_G;
        g_inputsUp[1].ki.dwFlags = KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP;

        // Single F (for alternate mode)
        g_fDown[0] = g_inputsDown[0];
        g_fUp[0]   = g_inputsUp[0];
        // Single G
        g_gDown[0] = g_inputsDown[1];
        g_gUp[0]   = g_inputsUp[1];

        // Raise system timer resolution to 1 ms for the whole session.
        timeBeginPeriod(1);

        Thread clickThread = new Thread(ClickerThread);
        clickThread.Priority     = ThreadPriority.AboveNormal;
        clickThread.IsBackground = true;
        clickThread.Start();

        if (g_headless)
            RunHeadless(cfgPath);
        else
            RunInteractive();

        g_running = false;
        timeEndPeriod(1);
    }

    // ------------------------------------------------------------------
    //  HEADLESS: driven by the Python GUI
    // ------------------------------------------------------------------
    static void RunHeadless(string cfgPath)
    {
        LoadConfig(cfgPath, false);
        g_configuring = false;

        // Machine-readable readiness line for Python.
        EmitStatus();
        Console.Out.Flush();

        bool keyWasPressed = (g_toggleKey != 0) &&
                             ((GetAsyncKeyState(g_toggleKey) & 0x8000) != 0);
        DateTime lastReload = DateTime.MinValue;

        while (g_running)
        {
            // Hot cfg reload: the GUI changes CPS/mode without restarting the exe.
            try
            {
                DateTime w = File.GetLastWriteTimeUtc(cfgPath);
                if (w > lastReload)
                {
                    lastReload = w;
                    LoadConfig(cfgPath, true);
                }
            }
            catch { /* file busy being written — retry next tick */ }

            // F6 — global emergency stop for the whole process.
            if ((GetAsyncKeyState(VK_F6) & 0x8000) != 0)
            {
                g_active = false;
                Console.WriteLine("EXIT");
                Console.Out.Flush();
                g_running = false;
                break;
            }

            if (g_toggleKey != 0)
            {
                bool keyIsPressed = (GetAsyncKeyState(g_toggleKey) & 0x8000) != 0;
                if (keyIsPressed && !keyWasPressed)
                {
                    g_active = !g_active;
                    Console.WriteLine(g_active ? "STATUS:ACTIVE" : "STATUS:PAUSED");
                    Console.Out.Flush();
                }
                keyWasPressed = keyIsPressed;
            }

            Thread.Sleep(10);
        }
    }

    // Reads a cfg file in key=value format.
    static void LoadConfig(string path, bool isReload)
    {
        try
        {
            foreach (string raw in File.ReadAllLines(path))
            {
                string line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue;
                int eq = line.IndexOf('=');
                if (eq <= 0) continue;
                string key = line.Substring(0, eq).Trim().ToLowerInvariant();
                string val = line.Substring(eq + 1).Trim();

                switch (key)
                {
                    case "cps":
                        int cps;
                        if (int.TryParse(val, NumberStyles.Integer, CultureInfo.InvariantCulture, out cps) && cps > 0)
                            g_cps = cps;
                        break;
                    case "mode":
                        g_simultaneous = val.Equals("sim", StringComparison.OrdinalIgnoreCase);
                        break;
                    case "togglekey":
                        int tk;
                        if (int.TryParse(val, NumberStyles.Integer, CultureInfo.InvariantCulture, out tk))
                            g_toggleKey = tk;
                        break;
                    case "autostart":
                        if (!isReload) // autostart applies only on the initial load
                            g_active = (val == "1" || val.Equals("true", StringComparison.OrdinalIgnoreCase));
                        break;
                }
            }
        }
        catch { /* if reading fails — keep defaults/previous values */ }

        if (isReload)
        {
            Console.WriteLine("RELOAD|cps=" + g_cps + "|mode=" + (g_simultaneous ? "sim" : "alt") +
                              "|toggleKey=" + g_toggleKey);
            Console.Out.Flush();
        }
    }

    static void EmitStatus()
    {
        Console.WriteLine("READY|cps=" + g_cps + "|mode=" + (g_simultaneous ? "sim" : "alt") +
                          "|toggleKey=" + g_toggleKey + "|autostart=" + (g_active ? "1" : "0"));
        Console.WriteLine(g_active ? "STATUS:ACTIVE" : "STATUS:PAUSED");
    }

    // ------------------------------------------------------------------
    //  INTERACTIVE: original console behaviour
    // ------------------------------------------------------------------
    static void RunInteractive()
    {
        bool keyWasPressed = false;

        while (g_running)
        {
            if (g_configuring)
            {
                ConfigureSettings();
                keyWasPressed = (GetAsyncKeyState(g_toggleKey) & 0x8000) != 0;
            }

            if ((GetAsyncKeyState(VK_F6) & 0x8000) != 0)
            {
                g_active      = false;
                g_configuring = true;
                Thread.Sleep(500);
                continue;
            }

            if (g_toggleKey != 0)
            {
                bool keyIsPressed = (GetAsyncKeyState(g_toggleKey) & 0x8000) != 0;

                if (keyIsPressed && !keyWasPressed)
                {
                    g_active = !g_active;
                    Console.ForegroundColor = g_active ? ConsoleColor.Green : ConsoleColor.Red;
                    Console.WriteLine(g_active ? "[STATUS: RUNNING]" : "[STATUS: PAUSED]");
                    Console.ResetColor();
                }

                keyWasPressed = keyIsPressed;
            }

            Thread.Sleep(10);
        }
    }

    static void ConfigureSettings()
    {
        g_active = false;
        Console.Clear();
        Console.WriteLine("=== CLICKER SETTINGS (X64 STRUCT) ===");
        Console.WriteLine("Will click: F and G");
        Console.WriteLine("\n1. Press ANY key to use as ON/OFF...");

        Thread.Sleep(500);

        bool found = false;
        while (!found)
        {
            for (int i = 8; i < 190; i++)
            {
                if (i == VK_F6) continue;
                if ((GetAsyncKeyState(i) & 0x8000) != 0)
                {
                    g_toggleKey = i;
                    Console.WriteLine("Key selected! (Code: " + i + ")");
                    found = true;
                    break;
                }
            }
            Thread.Sleep(10);
        }

        Thread.Sleep(500);

        Console.Write("\n2. Enter CPS (20-50 recommended for games): ");
        string input = Console.ReadLine();

        int rawCps;
        if (!int.TryParse(input, out rawCps) || rawCps <= 0)
            rawCps = 50; // Safe default

        g_cps = rawCps;

        Console.WriteLine("\n3. Key mode:");
        Console.WriteLine("   [1] Alternate F/G  (recommended - half the load, higher FPS)");
        Console.WriteLine("   [2] Simultaneous F+G (legacy mode, more events)");
        Console.Write("Choice (Enter = 1): ");
        string modeInput = Console.ReadLine();
        g_simultaneous = (modeInput != null && modeInput.Trim() == "2");

        Console.Clear();
        Console.WriteLine("=== CLICKER READY ===");
        Console.WriteLine("Activation     : [Code " + g_toggleKey + "]");
        Console.WriteLine("Spam keys      : F + G (" + (g_simultaneous ? "simultaneous" : "alternate") + ")");
        Console.WriteLine("Speed (CPS)    : ~" + g_cps);
        Console.WriteLine("-------------------------------------------");
        Console.WriteLine("1. Run the game AS ADMINISTRATOR (important!).");
        Console.WriteLine("2. Press the activation key to start.");
        Console.WriteLine("-------------------------------------------");

        g_configuring = false;
    }

    // ------------------------------------------------------------------
    //  Clicker thread (essentially unchanged)
    // ------------------------------------------------------------------
    static void ClickerThread()
    {
        long frequency;
        QueryPerformanceFrequency(out frequency);

        // Pin the clicker thread to the last CPU core.
        int cores = Environment.ProcessorCount;
        if (cores > 1)
        {
            UIntPtr mask = (UIntPtr)(1UL << (cores - 1)); // top core only
            SetThreadAffinityMask(GetCurrentThread(), mask);
        }

        bool useF = true; // which key to press in alternate mode

        while (g_running)
        {
            if (g_active && !g_configuring)
            {
                double totalCycleTime = 1.0 / g_cps;
                double holdTime = totalCycleTime / 2.0;

                long t1;

                INPUT[] down, up;
                if (g_simultaneous)
                {
                    down = g_inputsDown;
                    up   = g_inputsUp;
                }
                else
                {
                    down = useF ? g_fDown : g_gDown;
                    up   = useF ? g_fUp   : g_gUp;
                    useF = !useF;
                }

                // Down
                QueryPerformanceCounter(out t1);
                SendInput((uint)down.Length, down, g_inputSize);
                WaitPrecise(t1, holdTime, frequency);

                // Up
                QueryPerformanceCounter(out t1);
                SendInput((uint)up.Length, up, g_inputSize);
                WaitPrecise(t1, totalCycleTime - holdTime, frequency);
            }
            else
            {
                Thread.Sleep(10);
            }
        }
    }

    // Hybrid wait: sleep almost the whole interval, spin the last ~0.6 ms.
    const double SPIN_MARGIN = 0.002;

    static void WaitPrecise(long startTicks, double targetSeconds, long frequency)
    {
        long t2;

        if (targetSeconds > SPIN_MARGIN)
        {
            while (true)
            {
                QueryPerformanceCounter(out t2);
                double elapsed = (double)(t2 - startTicks) / frequency;
                if (elapsed >= targetSeconds - SPIN_MARGIN) break;
                Thread.Sleep(1);
            }
        }

        do { QueryPerformanceCounter(out t2); }
        while ((double)(t2 - startTicks) / frequency < targetSeconds);
    }
}
