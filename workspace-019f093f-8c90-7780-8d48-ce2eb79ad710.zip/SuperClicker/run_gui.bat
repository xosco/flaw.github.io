@echo off
REM ============================================================
REM  Launch the SuperClicker window (Python + HTML/CSS/JS)
REM  Run THIS FILE as administrator so the clicks reach the game.
REM ============================================================
cd /d "%~dp0python"

REM Install the dependency on first run (quietly).
python -c "import webview" 2>nul
if %ERRORLEVEL% neq 0 (
    echo Installing pywebview...
    python -m pip install --upgrade pip
    python -m pip install -r requirements.txt
)

python app.py
if %ERRORLEVEL% neq 0 pause
