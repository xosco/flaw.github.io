# SuperClicker

High-precision autoclicker: a **C# core** + a **polished window in Python + HTML/CSS/JS**.

| Layer | Technology | File |
|------|-----------|------|
| Input core | C# / WinAPI (SendInput, scancodes, hybrid timer) | `csharp/clicker.cs` |
| Bridge | Python (subprocess + cfg + stdout) | `python/backend.py` |
| Window | pywebview (frameless) + HTML/CSS/JS — Space Grotesk, animations, Windows-style title bar | `ui/index.html` |

## Run it (development / from source)
```
start.bat                 :: builds the core if needed, opens the window
```
(Or step by step: `csharp\build.bat`, then `run_gui.bat`.)

## Make a distributable EXE (for your website)
```
build_exe\build_exe.bat   :: produces build_exe\dist\flaw.exe
```
`flaw.exe` is a single, self-contained file — it bundles Python, pywebview,
the UI and the C# core. End users just **double-click it; nothing to install**.
Tell them to run it **as administrator** so clicks reach games.

Full instructions: **[USER_GUIDE.md](USER_GUIDE.md)**

> Windows x64 only.
