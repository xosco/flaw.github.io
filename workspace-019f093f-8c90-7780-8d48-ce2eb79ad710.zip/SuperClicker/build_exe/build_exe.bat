@echo off
REM ============================================================
REM  Build a STANDALONE flaw.exe for distribution.
REM  Output: build_exe\dist\flaw.exe  (single file, no install needed)
REM
REM  Requirements on YOUR machine (the builder), not on users':
REM    - Python 3.9+  (with pip)
REM    - .NET Framework (for the C# core)  - already in Windows
REM ============================================================
setlocal
cd /d "%~dp0"

echo.
echo [1/3] Ensuring the C# core is built...
if not exist "..\bin\SuperClicker.exe" (
    echo     Core missing - building it now...
    call "..\csharp\build.bat"
)
if not exist "..\bin\SuperClicker.exe" (
    echo [ERROR] Could not find or build ..\bin\SuperClicker.exe
    pause
    exit /b 1
)

echo.
echo [2/3] Installing build tools (PyInstaller + pywebview)...
python -m pip install --upgrade pip
python -m pip install pyinstaller pywebview

echo.
echo [3/3] Packaging flaw.exe...
python -m PyInstaller --clean --noconfirm flaw.spec

if not exist "dist\flaw.exe" (
    echo.
    echo [ERROR] Build failed - dist\flaw.exe was not created.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  DONE!  Your distributable file:
echo     %~dp0dist\flaw.exe
echo  Share THIS single file. Users just double-click it.
echo  (Remind them to run it as administrator for games.)
echo ============================================================
pause
