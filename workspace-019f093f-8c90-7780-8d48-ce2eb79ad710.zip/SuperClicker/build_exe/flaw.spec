# -*- mode: python ; coding: utf-8 -*-
#
# PyInstaller spec for flaw — produces a single, standalone flaw.exe that
# bundles Python, pywebview, the HTML UI and the C# core. End users just run
# flaw.exe; nothing needs to be installed.
#
# Build with:   build_exe\build_exe.bat   (or: pyinstaller flaw.spec)
#
import os

# This .spec lives in SuperClicker/build_exe/, project root is one level up.
ROOT = os.path.abspath(os.path.join(os.getcwd()))
# When PyInstaller runs the spec, CWD is wherever it's invoked; we resolve the
# project root relative to this spec's own location for robustness.
SPEC_DIR = os.path.dirname(os.path.abspath(SPEC))            # noqa: F821
PROJ = os.path.dirname(SPEC_DIR)

datas = [
    (os.path.join(PROJ, "ui", "index.html"), "ui"),
    (os.path.join(PROJ, "bin", "SuperClicker.exe"), "bin"),
]

a = Analysis(
    [os.path.join(PROJ, "python", "app.py")],
    pathex=[os.path.join(PROJ, "python")],
    binaries=[],
    datas=datas,
    hiddenimports=["webview", "webview.platforms.edgechromium"],
    hookspath=[],
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)

_icon = os.path.join(PROJ, "build_exe", "flaw.ico")
_verfile = os.path.join(PROJ, "build_exe", "version_info.txt")

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="flaw",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    runtime_tmpdir=None,
    console=False,          # no console window — GUI app
    icon=_icon if os.path.exists(_icon) else None,
    version=_verfile if os.path.exists(_verfile) else None,
)
